export class Product {
    contact?: string;
    lob?: string;
    name?: string;
    status?: string;
    user_number?: number;
}
