export class SideNavModel {
  title: string;
  icon?: string;
  route?: string;
}
