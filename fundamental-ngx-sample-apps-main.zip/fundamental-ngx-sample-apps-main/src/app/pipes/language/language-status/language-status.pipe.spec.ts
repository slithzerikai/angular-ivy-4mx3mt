import { LanguageStatusPipe } from './language-status.pipe';

describe('LanguageStatusPipe', () => {
  it('create an instance', () => {
    const pipe = new LanguageStatusPipe();
    expect(pipe).toBeTruthy();
  });
});
