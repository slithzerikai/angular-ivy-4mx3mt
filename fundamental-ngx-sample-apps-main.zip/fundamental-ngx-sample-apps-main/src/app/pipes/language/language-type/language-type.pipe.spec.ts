import { LanguageTypePipe } from './language-type.pipe';

describe('LanguageTypePipe', () => {
  it('create an instance', () => {
    const pipe = new LanguageTypePipe();
    expect(pipe).toBeTruthy();
  });
});
