export const environment = {
  production: true,
    firebase: {
      apiKey: "AIzaSyAxrGooEkauobDqqcyavI1a8YJYLpK-cjQ",
      authDomain: "fundamental-demo-app.firebaseapp.com",
      databaseURL: "https://fundamental-demo-app.firebaseio.com",
      projectId: "fundamental-demo-app",
      storageBucket: "fundamental-demo-app.appspot.com",
      messagingSenderId: "267773100353",
      appId: "1:267773100353:web:e5464549cff013a51ea1c0",
      measurementId: "G-HPGDYLM0FG"
    }
};
